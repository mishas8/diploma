﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Diplom
{
    public partial class Form3 : Form
    {
        public Form3(Result e1, Result e2, Result e3, Result e4, Result e5)
        {
            InitializeComponent();
            textBox1.Text = string.Format("u1 = {0:f5}\r\nu2 = {1:f5}\r\ng1 = {2:f5}\r\ng2 = {3:f5}\r\ng0 = {4:f5}\r\ngmax = {5:f5}",
                e1.u[0], e1.u[1], e1.g[1], e1.g[2], e1.g[0], e1.gmax);
            textBox2.Text = string.Format("u1 = {0:f5}\r\nu2 = {1:f5}\r\ng1 = {2:f5}\r\ng2 = {3:f5}\r\ng0 = {4:f5}\r\ngmax = {5:f5}",
                e2.u[0], e2.u[1], e2.g[1], e2.g[2], e2.g[0], e2.gmax);
            textBox3.Text = string.Format("u1 = {0:f5}\r\nu2 = {1:f5}\r\ng1 = {2:f5}\r\ng2 = {3:f5}\r\ng0 = {4:f5}\r\ngmax = {5:f5}",
                e3.u[0], e3.u[1], e3.g[1], e3.g[2], e3.g[0], e3.gmax);
            textBox4.Text = string.Format("u1 = {0:f5}\r\nu2 = {1:f5}\r\ng1 = {2:f5}\r\ng2 = {3:f5}\r\ng0 = {4:f5}\r\ngmax = {5:f5}",
                e4.u[0], e4.u[1], e4.g[1], e4.g[2], e4.g[0], e4.gmax);
            string s = "";
            for (int i = 1; i <= e5.u.Count; i++)
                s += string.Format("u{0} = {1:f5}\r\n", i, e5.u[i - 1]);
            for (int i = 1; i < e5.g.Count; i++)
                s += string.Format("g{0} = {1:f5}\r\n", i, e5.g[i]);
            s += string.Format("g{0} = {1:f5}\r\n", 0, e5.g[0]);
            s += string.Format("gmax = {0:f5}", e5.gmax);
            textBox5.Text = s;
            ActiveControl = button1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(saveFileDialog1.FileName))
                {
                    sw.WriteLine(label1.Text);
                    sw.WriteLine(textBox1.Text);
                    sw.WriteLine();
                    sw.WriteLine(label2.Text);
                    sw.WriteLine(textBox2.Text);
                    sw.WriteLine();
                    sw.WriteLine(label3.Text);
                    sw.WriteLine(textBox3.Text);
                    sw.WriteLine();
                    sw.WriteLine(label4.Text);
                    sw.WriteLine(textBox4.Text);
                    sw.WriteLine();
                    sw.WriteLine(label5.Text);
                    sw.WriteLine(textBox5.Text);
                    sw.WriteLine();
                }
            }
        }
    }
}
