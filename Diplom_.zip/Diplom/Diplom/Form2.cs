﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Diplom
{
    public partial class Form2 : Form
    {
        public Form2(string text, List<double> g, int n)
        {
            InitializeComponent();
            label2.Text = text;

            int j = 0;
            while (j < panel1.Controls.Count)
            {
                var c = panel1.Controls[j];
                if (c is Label)
                {
                    Console.WriteLine(c.ToString());
                    if ((c as Label).Name.Substring(0, 2) == "lg")
                        (c as Label).Dispose();
                    else
                        j++;
                }
                else if (c is TextBox)
                {
                    if ((c as TextBox).Name[0] == 'g')
                        (c as TextBox).Dispose();
                    else
                        j++;
                }
                else
                    j++;
            }

            for (int i = 0; i < n; i++)
            {
                Label l1 = new Label();
                l1.Name = string.Format("lg{0}", i + 1);
                l1.Size = new Size(28, 13);
                l1.Text = string.Format("g{0} =", i + 1);
                l1.Location = new Point(11, 25 + 25 * i);
                panel1.Controls.Add(l1);
                TextBox t1 = new TextBox();
                t1.Name = string.Format("g{0}", i + 1);
                t1.Location = new Point(41, 22 + 26 * i);
                t1.ReadOnly = true;
                t1.BackColor = Color.White;
                t1.Text = g[i + 1].ToString("F5");
                panel1.Controls.Add(t1);
            }
            g0.Text = g[0].ToString("F5");
            ActiveControl = label2;
        }
    }
}
