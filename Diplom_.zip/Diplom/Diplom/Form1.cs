﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Diplom
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
            openFileDialog1.InitialDirectory = System.IO.Directory.GetCurrentDirectory();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double _s = double.Parse(s.Text.Replace('.', ',')),
                _c = double.Parse(c.Text.Replace('.', ',')),
                _a = double.Parse(a.Text.Replace('.', ','));
            int _n = (int)(n.Value);
            List<double> p = new List<double>();
            foreach (var t in panel1.Controls)
                if (t is TextBox)
                    p.Add(double.Parse((t as TextBox).Text.Replace('.', ',')));
            List<double> r = new List<double>();
            foreach (var t in panel2.Controls)
                if (t is TextBox)
                    r.Add(double.Parse((t as TextBox).Text.Replace('.', ',')));
            Result res = new Result();
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    Result res1 = Eval.FindEquality(_s, _c, p[0], p[1], r[0], r[1], _a);
                    Result res2 = Eval.FindEqualCoop(_s, _c, p[0], p[1], r[0], r[1], _a);
                    Result res3 = Eval.FindHierarchy(_s, _c, p[0], p[1], r[0], r[1], _a);
                    Result res4 = Eval.FindHierCoop(_s, _c, p[0], p[1], r[0], r[1], _a);
                    Result res5 = Eval.FindN(_c, p, r, _a, _n);
                    Form3 f3 = new Form3(res1, res2, res3, res4, res5);
                    f3.ShowDialog();
                    break;
                case 1:
                    res = Eval.FindEquality(_s, _c, p[0], p[1], r[0], r[1], _a);
                    Form2 f2 = new Form2("Равноправие", res.g, 2);
                    f2.ShowDialog();
                    break;
                case 2:
                    res = Eval.FindEqualCoop(_s, _c, p[0], p[1], r[0], r[1], _a);
                    f2 = new Form2("Равноправие + Кооперация", res.g, 2);
                    f2.ShowDialog();
                    break;
                case 3:
                    res = Eval.FindHierarchy(_s, _c, p[0], p[1], r[0], r[1], _a);
                    f2 = new Form2("Иерархия", res.g, 2);
                    f2.ShowDialog();
                    break;
                case 4:
                    res = Eval.FindHierCoop(_s, _c, p[0], p[1], r[0], r[1], _a);
                    f2 = new Form2("Иерархия + Кооперация", res.g, 2);
                    f2.ShowDialog();
                    break;
                case 5:
                    res = Eval.FindN(_c, p, r, _a, _n);
                    f2 = new Form2(string.Format("{0} участников", _n), res.g, _n);
                    f2.ShowDialog();
                    break;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                case 5:
                    n.Enabled = true;
                    break;
                default:
                    n.Enabled = false;
                    break;
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            int j = 0;
            while (j < panel1.Controls.Count)
            {
                var c = panel1.Controls[j];
                if (c is Label)
                {
                    Console.WriteLine(c.ToString());
                    if ((c as Label).Name.Substring(0, 2) == "lp")
                        (c as Label).Dispose();
                    else
                        j++;
                }
                else if (c is TextBox)
                {
                    if ((c as TextBox).Name[0] == 'p')
                        (c as TextBox).Dispose();
                    else
                        j++;
                }
                else
                    j++;
            }

            j = 0;
            while (j < panel2.Controls.Count)
            {
                var c = panel2.Controls[j];
                if (c is Label)
                {
                    Console.WriteLine(c.ToString());
                    if ((c as Label).Name.Substring(0, 2) == "lr")
                        (c as Label).Dispose();
                    else
                        j++;
                }
                else if (c is TextBox)
                {
                    if ((c as TextBox).Name[0] == 'r')
                        (c as TextBox).Dispose();
                    else
                        j++;
                }
                else
                    j++;
            }
            
            for (int i = 0; i < n.Value; i++)
            {
                Label l1 = new Label();
                l1.Name = string.Format("lp{0}", i + 1);
                l1.Size = new Size(28, 13);
                l1.Text = string.Format("p{0} =", i + 1);
                l1.Location = new Point(11, 25 + 25 * i);
                panel1.Controls.Add(l1);
                Label l2 = new Label();
                l2.Name = string.Format("lr{0}", i + 1);
                l2.Size = new Size(28, 13);
                l2.Text = string.Format("r{0} =", i + 1);
                l2.Location = new Point(11, 25 + 25 * i);
                panel2.Controls.Add(l2);
                TextBox t1 = new TextBox();
                t1.Name = string.Format("p{0}", i + 1);
                t1.Location = new Point(41, 22 + 26 * i);
                panel1.Controls.Add(t1);
                TextBox t2 = new TextBox();
                t2.Name = string.Format("r{0}", i + 1);
                t2.Location = new Point(41, 22 + 26 * i);
                panel2.Controls.Add(t2);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                using (System.IO.StreamReader sr = new System.IO.StreamReader(openFileDialog1.FileName))
                {
                    comboBox1.SelectedIndex = int.Parse(sr.ReadLine().Split(' ')[1]);
                    s.Text = sr.ReadLine().Split(' ')[3];
                    int _n = 2;
                    if (comboBox1.SelectedIndex == 0 || comboBox1.SelectedIndex == 5)
                        _n = int.Parse(sr.ReadLine().Split(' ')[2]);
                    n.Value = _n;
                    c.Text = sr.ReadLine().Split(' ')[2];
                    a.Text = sr.ReadLine().Split(' ')[2];
                    for (int i = 0; i < _n; i++)
                        (panel1.Controls["p" + (i + 1)] as TextBox).Text = sr.ReadLine().Split(' ')[1];
                    for (int i = 0; i < _n; i++)
                        (panel2.Controls["r" + (i + 1)] as TextBox).Text = sr.ReadLine().Split(' ')[1];
                }
            }
            s_TextChanged(s, e);
        }

        private void s_TextChanged(object sender, EventArgs e)
        {
            double result;
            bool enabled = false;
            if (double.TryParse(s.Text.Replace('.', ','), out result))
                if (double.TryParse(c.Text.Replace('.', ','), out result))
                    if (double.TryParse(a.Text.Replace('.', ','), out result))
                    {
                        for (int i = 0; i < n.Value; i++)
                        {
                            if (!double.TryParse((panel1.Controls["p" + (i + 1)] as TextBox).Text.Replace('.', ','), out result))
                                break;
                        }
                        for (int i = 0; i < n.Value; i++)
                        {
                            if (!double.TryParse((panel2.Controls["r" + (i + 1)] as TextBox).Text.Replace('.', ','), out result))
                                break;
                        }
                        enabled = true;
                    }
            button2.Enabled = enabled;
        }
    }
}