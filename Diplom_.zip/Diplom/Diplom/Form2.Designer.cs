﻿namespace Diplom
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.g2 = new System.Windows.Forms.TextBox();
            this.lg2 = new System.Windows.Forms.Label();
            this.g1 = new System.Windows.Forms.TextBox();
            this.lg1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.g0 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(153, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Результаты:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "<Название случая>";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.g2);
            this.panel1.Controls.Add(this.lg2);
            this.panel1.Controls.Add(this.g1);
            this.panel1.Controls.Add(this.lg1);
            this.panel1.Location = new System.Drawing.Point(12, 61);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(191, 75);
            this.panel1.TabIndex = 2;
            this.panel1.Text = "Функции выигрыша i-ых игроков:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(177, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Функции выигрыша i-ых игроков:";
            // 
            // g2
            // 
            this.g2.BackColor = System.Drawing.Color.White;
            this.g2.Location = new System.Drawing.Point(41, 48);
            this.g2.Name = "g2";
            this.g2.ReadOnly = true;
            this.g2.Size = new System.Drawing.Size(100, 20);
            this.g2.TabIndex = 11;
            // 
            // lg2
            // 
            this.lg2.AutoSize = true;
            this.lg2.Location = new System.Drawing.Point(11, 50);
            this.lg2.Name = "lg2";
            this.lg2.Size = new System.Drawing.Size(28, 13);
            this.lg2.TabIndex = 10;
            this.lg2.Text = "g2 =";
            // 
            // g1
            // 
            this.g1.BackColor = System.Drawing.Color.White;
            this.g1.Location = new System.Drawing.Point(41, 22);
            this.g1.Name = "g1";
            this.g1.ReadOnly = true;
            this.g1.Size = new System.Drawing.Size(100, 20);
            this.g1.TabIndex = 11;
            // 
            // lg1
            // 
            this.lg1.AutoSize = true;
            this.lg1.Location = new System.Drawing.Point(11, 25);
            this.lg1.Name = "lg1";
            this.lg1.Size = new System.Drawing.Size(28, 13);
            this.lg1.TabIndex = 10;
            this.lg1.Text = "g1 =";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.g0);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(13, 142);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(224, 56);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Функция общественного благополучия:";
            // 
            // g0
            // 
            this.g0.BackColor = System.Drawing.Color.White;
            this.g0.Location = new System.Drawing.Point(39, 23);
            this.g0.Name = "g0";
            this.g0.ReadOnly = true;
            this.g0.Size = new System.Drawing.Size(100, 20);
            this.g0.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "g0 =";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 208);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form2";
            this.Text = "Результаты для отдельного случая";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox g2;
        private System.Windows.Forms.Label lg2;
        private System.Windows.Forms.TextBox g1;
        private System.Windows.Forms.Label lg1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox g0;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
    }
}