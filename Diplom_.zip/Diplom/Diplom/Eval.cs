﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diplom
{
    public struct Result
    {
        public List<double> u;
        public List<double> g;
        public double gmax;

        public Result(List<double> _u, List<double> _g, double _gmax)
        {
            u = new List<double>(_u);
            g = new List<double>(_g);
            gmax = _gmax;
        }
    }

    public class Eval
    {
        public static Result FindEquality(double s, double c, double p1, double p2, double r1, double r2, double a)
        {
            double s1 = 1 - s,
                u1 = (s * (r1 + 1) * (p2 + s1 * c) - p1 * s1 * c * (2 + r2)) / (p1 * s1 + p2 * s + s1 * s * c),
                u2 = (c * s1 * (r2 + 1) * (p1 * s1 + p2 * s + s1 * s * c) - p2 * s * (p2 + s1 * c) * (2 + r1)
                    + p1 * p2 * s1 * (r2 + 1)) / ((p1 * s1 + p2 * s + s1 * s * c) * (p2 + s1 * c));

            // I
            //if (p1 <= s * c * (r1 + 1) / (1 + u2) && p1 >= s * c / (1 + u2 + r1)
            //    && p2 <= s1 * c * (r2 + 1) / (1 + u1) && p2 >= s1 * c / (1 + u1 + r2))
            //    ;
            // II
            if (p1 > s * c * (r1 + 1) / (1 + u2) && p2 <= s1 * c * (r2 + 1) / (1 + u1) && p2 >= s1 * c / (1 + u1 + r2))
            {
                u1 = 0;
                u2 = (s1 * c * (r2 + 1) - p2) / (s1 * c + p2);
            }
            // III
            else if (p1 < s * c / (1 + u2 + r1) && p2 <= s1 * c * (r2 + 1) / (1 + u1) && p2 >= s1 * c / (1 + u1 + r2))
            {
                u1 = r1;
                u2 = (s1 * c * (r2 + 1) - p2 * (r1 + 1)) / (s1 * c + p2);
            }
            // IV
            else if (p1 <= s * c * (r1 + 1) / (1 + u2) && p1 >= s * c / (1 + u2 + r1) && p2 <= s1 * c * (r2 + 1) / (1 + u1))
            {
                u1 = (s * c * (r1 + 1) - p1) / (s * c + p1);
                u2 = 0;
            }
            // V
            else if (p1 <= s * c * (r1 + 1) / (1 + u2) && p2 < s1 * c * (r2 + 1) / (1 + u1 + r2))
            {
                u1 = (s * c * (r1 + 1) - p1 * (r2 + 1)) / (s * c + p1);
                u2 = r2;
            }
            // VI
            else if (p1 > s * c * (r1 + 1) / (1 + u2) && p2 > s1 * c * (r2 + 1) / (1 + u1))
            {
                u1 = 0;
                u2 = 0;
            }
            // VII
            else if (p1 > s * c * (r1 + 1) / (1 + u2) && p2 < s1 * c * (r2 + 1) / (1 + u1 + r2))
            {
                u1 = 0;
                u2 = r2;
            }
            // VIII
            else if (p1 < s * c * (r1 + 1) / (1 + u2) && p2 > s1 * c * (r2 + 1) / (1 + u1 + r2))
            {
                u1 = r1;
                u2 = 0;
            }
            // IX
            else if (p1 < s * c / (1 + u2 + r1) && p2 < s1 * c / (1 + u1 + r2))
            {
                u1 = r1;
                u2 = r2;
            }

            double g1 = p1 * Math.Log(1 + r1 - u1, a) + s * c * Math.Log(1 + u1 + u2, a),
                g2 = p2 * Math.Log(1 + r2 - u2, a) + s1 * c * Math.Log(1 + u1 + u2, a),
                g0 = p1 * Math.Log(1 + r1 - u1, a) + p2 * Math.Log(1 + r2 - u2, a) + c * Math.Log(1 + u1 + u2, a),
                gmax = Math.Max(g1, Math.Max(g2, g0));
            List<double> u = new List<double>() { u1 < 0 ? 0 : (u1 > r1 ? r1 : u1), u2 < 0 ? 0 : (u2 > r2 ? r2 : u2) };
            List<double> g = new List<double>() { g0, g1, g2};
            return new Result(u, g, gmax);
        }

        public static Result FindEqualCoop(double s, double c, double p1, double p2, double r1, double r2, double a)
        {
            double s1 = 1 - s;
            double u1 = ((r1 + 1) * (p2 + c) - p1 * c * (2 + r2)) / (p1 + p2 + c),
                u2 = (c * (r2 + 1) * (p1 + p2 + c) - s * (p2 + c) * (2 + r1) + p1 * p2 * (r2 + 1)) / ((p1 + p2 + c) * (p2 + c));

            // I
            //if (p1 <= c * (r1 + 1) / (1 + u2) && p1 >= c / (1 + u2 + r1)
            //    && p2 <= c * (r2 + 1) / (1 + u1) && p2 >= c / (1 + u1 + r2))
            //    ;
            // II
            if (p1 > c * (r1 + 1) / (1 + u2) && p2 <= c * (r2 + 1) / (1 + u1) && p2 >= c / (1 + u1 + r2))
            {
                u1 = 0;
                u2 = (c * (r2 + 1) - p2) / (c + p2);
            }
            // III
            else if (p1 < c / (1 + u2 + r1) && p2 <= c * (r2 + 1) / (1 + u1) && p2 >= c / (1 + u1 + r2))
            {
                u1 = r1;
                u2 = (c * (r2 + 1) - p2 * (r1 + 1)) / (c + p2);
            }
            // IV
            else if (p1 <= c * (r1 + 1) / (1 + u2) && p1 >= c / (1 + u2 + r1) && p2 <= c * (r2 + 1) / (1 + u1))
            {
                u1 = (c * (r1 + 1) - p1) / (c + p1);
                u2 = 0;
            }
            // V
            else if (p1 <= c * (r1 + 1) / (1 + u2) && p2 < c * (r2 + 1) / (1 + u1 + r2))
            {
                u1 = (c * (r1 + 1) - p1 * (r2 + 1)) / (c + p1);
                u2 = r2;
            }
            // VI
            else if (p1 > c * (r1 + 1) / (1 + u2) && p2 > c * (r2 + 1) / (1 + u1))
            {
                u1 = 0;
                u2 = 0;
            }
            // VII
            else if (p1 > c * (r1 + 1) / (1 + u2) && p2 < c * (r2 + 1) / (1 + u1 + r2))
            {
                u1 = 0;
                u2 = r2;
            }
            // VIII
            else if (p1 < c * (r1 + 1) / (1 + u2) && p2 > c * (r2 + 1) / (1 + u1 + r2))
            {
                u1 = r1;
                u2 = 0;
            }
            // IX
            else if (p1 < c / (1 + u2 + r1) && p2 < c / (1 + u1 + r2))
            {
                u1 = r1;
                u2 = r2;
            }

            double g1 = p1 * Math.Log(1 + r1 - u1, a) + s * c * Math.Log(1 + u1 + u2, a),
                g2 = p2 * Math.Log(1 + r2 - u2, a) + s1 * c * Math.Log(1 + u1 + u2, a),
                g0 = p1 * Math.Log(1 + r1 - u1, a) + p2 * Math.Log(1 + r2 - u2, a) + c * Math.Log(1 + u1 + u2, a),
                gmax = Math.Max(g1, Math.Max(g2, g0));
            List<double> u = new List<double>() { u1 < 0 ? 0 : (u1 > r1 ? r1 : u1), u2 < 0 ? 0 : (u2 > r2 ? r2 : u2) };
            List<double> g = new List<double>() { g0, g1, g2 };
            return new Result(u, g, gmax);
        }

        public static Result FindHierarchy(double s, double c, double p1, double p2, double r1, double r2, double a)
        {
            double r = r1 + r2, u1 = 0, u2 = 0, s1 = 1 - s;
            if (p1 <= c * s * (r + 1) / 2 && p1 >= c * s * (2 * r + 1) / (2 + r))
                u1 = (c * s * (r + 1) - 2 * p1) / (r * (p1 + c * s));
            else if (p1 <= c * s * r * (r + 1) && p1 >= c * s * (r * (r + 1) + 1) / 2)
                u1 = (c * s * r * (r + 1) - p1) / (p1 - c * s);
            else if (p1 < c * s * (r * (r + 1) + 1) / 2)
                u1 = 1;

            if (p2 <= s1 * c * (1 + r * u1) && p2 >= s1 * c * (u1 * r + 1))
            {
                if (u1 == 0)
                    u2 = 1;
                else
                    u2 = (s1 * c * (u1 * r + 1) - p2) / (u1 * r * (s1 * c + p2));
            }
            else if (p2 > s1 * c * (1 + r * u1))
                u2 = 0;
            else if (p2 < s1 * c / (1 + r * u1))
                u2 = 1;
            double g1 = p1 * Math.Log(1 + r - r * u1, a) + s * c * Math.Log(1 + u1 * u2 * r, a),
                g2 = p2 * Math.Log(1 + r * u1 * (1 - u2), a) + s1 * c * Math.Log(1 + u1 * u2 * r, a),
                g0 = p1 * Math.Log(1 + r - r * u1, a) + p2 * Math.Log(1 + r * u1 * (1 - u2), a) + c * Math.Log(1 + u1 * u2 * r, a),
                gmax = Math.Max(g1, Math.Max(g2, g0));
            List<double> u = new List<double>() { u1 < 0 ? 0 : (u1 > 1 ? 1 : u1), u2 < 0 ? 0 : (u2 > 1 ? 1 : u2) };
            List<double> g = new List<double>() { g0, g1, g2 };
            return new Result(u, g, gmax);
        }

        public static Result FindHierCoop(double s, double c, double p1, double p2, double r1, double r2, double a)
        {
            double r = r1 + r2, u1 = 0, u2 = 0, s1 = 1 - s;
            if (p2 <= c * (r + 1) / (1 - r) && p1 >= (c - p2) / r)
                u1 = ((p2 + c) * (r + 1) - 2 * p2) / (r * (p1 + p2 + c));
            else if (p1 <= p2 * (r + 1) && p1 >= p2 / (r + 1))
                u1 = (p2 * (r + 1) - p1) / ((p1 + p2) * r);
            else if (p1 <= c * (r + 1) && p1 >= c * (1 + 2 * r) / (r + 1))
                u1 = (c * (r + 1) - p1) / ((p1 + c) * r);
            else if (p1 <= c * (1 + 2 * r) / (r + 1))
                u1 = 1;

            if (p2 <= c * (1 + r * u1) && p2 >= c / (u1 * r + 1))
            {
                if (u1 == 0)
                    u2 = 1;
                else
                    u2 = (c * (u1 * r + 1) - p2) / (u1 * r * (c + p2));
            }
            else if (p2 > c * (1 + r * u1))
                u2 = 0;
            else if (p2 < c / (u1 * r + 1))
                u2 = 1;

            double g1 = p1 * Math.Log(1 + r - r * u1, a) + s * c * Math.Log(1 + u1 * u2 * r, a),
                g2 = p2 * Math.Log(1 + r * u1 * (1 - u2), a) + s1 * c * Math.Log(1 + u1 * u2 * r, a),
                g0 = p1 * Math.Log(1 + r - r * u1, a) + p2 * Math.Log(1 + r * u1 * (1 - u2), a) + c * Math.Log(1 + u1 * u2 * r, a),
                gmax = Math.Max(g1, Math.Max(g2, g0));
            List<double> u = new List<double>() { u1 < 0 ? 0 : (u1 > 1 ? 1 : u1), u2 < 0 ? 0 : (u2 > 1 ? 1 : u2) };
            List<double> g = new List<double>() { g0, g1, g2 };
            return new Result(u, g, gmax);
        }

        public static Result FindN(double c, List<double> p, List<double> r, double a, int n)
        {
            List<double> u = new List<double>();
            List<double> g = new List<double>();
            List<double> s = new List<double>();
            Random rand = new Random();
            double last = 1;
            for (int i = 0; i < n - 1; i++)
            {
                double si = rand.NextDouble() / (n - 1);
                if (si < 0.1)
                    si += 0.1;
                s.Add(si);
                last -= si;
            }
            s.Add(last);

            for (int i = 0; i < p.Count; i++)
            {
                double x = 0;
                for (int j = 0; j < n; j++)
                    x += (s[j] * c * (1 + r[j]) - n * p[j]) / (s[j] * c);
                double y = 1;
                for (int j = 0; j < n; j++)
                    y += p[j] / (s[j] * c);
                double ui = 1 + r[i] + p[i] / ((s[i] * c) * (1 + (x / y)));
                u.Add(ui < 0 ? 0 : (ui > r[i] ? r[i] : ui));
            }
            for (int i = 0; i < p.Count; i++)
            {
                double gi = 0;
                double x = 0;
                for (int j = 0; j < n; j++)
                    x += (s[j] * c * (1 + r[j]) - n * p[j]) / (s[j] * c);
                double y = 1;
                for (int j = 0; j < n; j++)
                    y += p[j] / (s[j] * c);
                gi = p[i] * Math.Log(1 + r[i] - u[i], a) + s[i] * c * Math.Log(1 + (x / y), a);
                g.Add(gi);
            }
            double _gi = 0;
            double _x = 0;
            for (int j = 0; j < n; j++)
                _x += (s[j] * c * (1 + r[j]) - n * p[j]) / (s[j] * c);
            double _y = 1;
            for (int j = 0; j < n; j++)
                _y += p[j] / (s[j] * c);
            for (int j = 0; j < n; j++)
                _gi += p[j] * Math.Log(1 + r[j] - u[j], a);
            _gi += c * Math.Log(1 + (_x / _y), a);
            g.Insert(0, _gi);
            return new Result(u, g, g.Max());
        }
    }
}
